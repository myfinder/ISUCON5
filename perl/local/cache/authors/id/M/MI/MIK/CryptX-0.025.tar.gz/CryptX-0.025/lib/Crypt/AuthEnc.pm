package Crypt::AuthEnc;

use strict;
use warnings;

sub CLONE_SKIP { 1 } # prevent cloning

1;

__END__
 
=head1 NAME

Crypt::AuthEnc - [internal only]

=cut